# A+B+C thesis extension package

This package contains **independently re-runnable** controlled ablation (A), empirical label ambiguity / exchangeability-reference (B), and dependence sensitivity (C) experiments for the life-insurance churn manuscript.

## Reproduce

1. Put `randomdata.csv` beside `thesis_extensions_AB_C.ipynb` (the CSV is deliberately **not redistributed** in the ZIP).
2. Install Python 3.10+ and the dependencies in `requirements.txt`.
3. Open `thesis_extensions_AB_C.ipynb` in Jupyter / VS Code / Colab and **Run All**.
4. Outputs are saved to `Thesis_Extensions_AB_C/tables`, `figures` (PNG / SVG / PDF), and `metadata`.

Independent reproduction: the new notebook does **not** import the paper notebook, original manuscript model objects, or any project-specific module.

## Evidence and limits

- A: five explicit random seeds for every level of the 2×2 design; retain the classifier configurations used in the study (LR, RF, GB).
- B: empirical conditional entropy and an **in-sample** group-majority oracle, with shuffled-label reference. This is not a population Bayes bound and does not certify the absence of information.
- C: representative seed 10, record- versus equal-group-weighted AUC, row and feature-group bootstrap. Feature groups are **not known customer/policy identifiers**.
- Rows are observational records with unclear customer independence and feature timing. No retention effectiveness is measured.

`metadata/experiment_manifest.json` preserves dataset SHA-256, model parameters, sampling seeds, and automatic validation checks. `MASTER_RESULTS.md` is the source-of-truth for thesis numerical interpretation. Treat simulated/permutation distributions as descriptive sensitivity diagnostics unless exchangeability/independence assumptions are defended.
