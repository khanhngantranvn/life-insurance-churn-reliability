# Mapping core paper -> thesis extensions

## Core paper (reference values taken from the supplied ICICC manuscript; not re-estimated in this file)
- 200,000 records; 63.636% Churn=Yes; BMI deterministically partitions all observed labels.
- After removing BMI, 1,769 distinct predictor feature vectors (all mixed-label).
- Original Scenario A with BMI: AUC-ROC 1.000 for LR/RF/GB.
- Original Scenario B without BMI and group-aware: AUC approximately 0.499–0.500 for three classifiers across ten splits.
- Stage 3: K-means k=2 matches Medical versus other premium categories; not a validated retention policy.

## Added thesis contribution A: factorized experimental design
- Four cells are defined by BMI included/excluded × random/group-aware split.
- Identical BMI-excluded feature-vector hash is used for grouping in both BMI conditions.
- Five split seeds (0–4), 3 model families, 60 fits in total.
- This separates predictor-exclusion and split-type *protocol choices* better than the two-cell comparison of the core paper. It is not a causal claim about unmeasured leakage.

## Added thesis contribution B: information sufficiency diagnostic
- Empirical H(Y|X), H(Y), group-majority in-sample oracle, mixed labels in the 1,769 groups.
- 400 shuffled-label references to contextualize finite-sample upward information gain.
- Avoid inference to population or independent customers; no ground truth data lineage.

## Added thesis contribution C: dependence sensitivity
- Representative seed 10 model scores.
- Record-weighted versus equal-group-weighted AUC.
- 300 row/bootstrap draws, plus 300 resampled feature-vector-group draws.
- This is a sensitivity analysis and cannot substitute external or patient/customer-level validation.

## Recommended thesis structure from these outputs
1. Dataset provenance / record-level constraints.
2. Predictor audit and deterministic proxy diagnostics (core).
3. Protocol-controlled factorial ablation (A).
4. Conditional-entropy / label-ambiguity analysis (B).
5. Stability and dependence-aware sensitivity (C).
6. Monetary segmentation as a deliberately limited descriptive extension (core).
7. Discussion of inference limits and deployment gate; conclusion.

## Figure references
- Extension Fig. E1: four-cell ablation, mean±SD.
- Extension Fig. E2: group-label mixture and exchangeable-label reference.
- Extension Fig. E3: model AUC distribution and group-weighted/group-resampled sensitivity.

## Do not claim
- BMI is proven *temporal* leakage.
- No real churn signal could exist in more informative data.
- Duplicate feature vectors mean duplicated policyholders.
- In-sample group-majority oracle accuracy is Bayes-optimal population accuracy.
- Group bootstrap yields valid customer-level confidence intervals.
- K-means shows intervention uplift or expected ROI.
