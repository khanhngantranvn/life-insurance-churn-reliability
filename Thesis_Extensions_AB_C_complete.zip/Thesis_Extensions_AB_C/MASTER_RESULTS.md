# Thesis Extensions: Master Results and Interpretation Boundaries

Generated from dataset SHA-256: `85700a0d3f6e05c394d6ccba4ac75018c33ebee75cd6b3bed48dd82fd28ccd5e`.

## A. Factorial ablation (5 seeds)

Both predictor inclusion and split strategy were manipulated separately; groups for group-aware splitting were ALWAYS computed without BMI. AUC summaries:

| split       | bmi      | model   |   auc_mean |   auc_sd |
|:------------|:---------|:--------|-----------:|---------:|
| Group-aware | Excluded | GB      |   0.499404 | 0.001995 |
| Group-aware | Excluded | LR      |   0.499808 | 0.001334 |
| Group-aware | Excluded | RF      |   0.498815 | 0.001079 |
| Group-aware | Included | GB      |   1        | 0        |
| Group-aware | Included | LR      |   1        | 0        |
| Group-aware | Included | RF      |   1        | 0        |
| Random      | Excluded | GB      |   0.500314 | 0.002265 |
| Random      | Excluded | LR      |   0.50004  | 0.00314  |
| Random      | Excluded | RF      |   0.501977 | 0.002473 |
| Random      | Included | GB      |   1        | 0        |
| Random      | Included | LR      |   1        | 0        |
| Random      | Included | RF      |   1        | 0        |

**Interpretation:** BMI retained performance tests possible label encoding; random vs group split comparisons reveal sensitivity to exact predictor-vector overlap. The splits are not chronological or external.

## B. Information and label ambiguity

- Groups with both churn labels: 1769/1769.
- H(Y) = 0.655484 nats; empirical H(Y|X) = 0.650963 nats; apparent I(X;Y) = 0.004521 nats.
- Global majority accuracy = 0.636360; in-sample group-label oracle accuracy = 0.636585; gain = 0.000225.
- Information-gain permutation reference: mean 0.004457, 95% simulation interval [0.004185, 0.004718].

**Interpretation:** The group-majority oracle is optimized on observed labels and cannot be advertised as a population Bayes upper bound. A positive raw empirical information gain is expected under finite-sample noise; compare it with the permutation reference. Exchangeability may be unrealistic if records are dependent.

## C. Robustness / uncertainty on representative split

| model   |   representative_seed |   test_records |   test_unique_groups |   auc_record_weighted |   auc_equal_group_weighted |   bootstrap_row_ci_low |   bootstrap_row_ci_high |   bootstrap_group_ci_low |   bootstrap_group_ci_high |   bootstrap_row_sd |   bootstrap_group_sd |
|:--------|----------------------:|---------------:|---------------------:|----------------------:|---------------------------:|-----------------------:|------------------------:|-------------------------:|--------------------------:|-------------------:|---------------------:|
| LR      |                    10 |          42380 |                  354 |              0.496974 |                   0.494203 |               0.491084 |                0.502772 |                 0.491528 |                  0.502378 |           0.0028   |             0.002718 |
| RF      |                    10 |          42380 |                  354 |              0.499833 |                   0.496598 |               0.494559 |                0.505169 |                 0.493689 |                  0.505247 |           0.002851 |             0.002729 |
| GB      |                    10 |          42380 |                  354 |              0.501169 |                   0.500075 |               0.495062 |                0.5072   |                 0.494908 |                  0.506505 |           0.003019 |             0.002851 |

**Interpretation:** Equal-group weighting changes the estimand from a random record to an equal contribution from each observed feature group. Resampling feature-vector groups checks a form of dependence sensitivity, NOT verified customer-level uncertainty. Raw row and group bootstrap intervals use 300 resamples; do not replace the paper's CI without explicitly updating its methodology.

## Critical limitations

1. The Kaggle source does not document a verified policyholder or policy ID, feature availability time, intervention outcomes, or external deployment data.
2. BMI's deterministic label association alone cannot prove temporal leakage.
3. Scenario A/B in the original paper changed both BMI and splitting; this factorial experiment isolates those protocol choices more cleanly.
4. The notebook is a dataset-specific empirical assessment, not proof that insurance churn is inherently unpredictable.
5. No benefit from retention campaigns can be inferred from this dataset.

## Figures

- E1_factorial_ablation_auc (A): AUC across four configurations.
- E2_label_ambiguity_and_information (B): mixed-label groups and permutation reference.
- E3_split_robustness_and_group_uncertainty (C): split variability and group-weighting uncertainty.

## Reproduction

Place `randomdata.csv` next to `thesis_extensions_AB_C.ipynb`, then run all cells. CSV and figure outputs are written to `Thesis_Extensions_AB_C/tables` and `Thesis_Extensions_AB_C/figures`. No core-paper notebook imports are needed.
