# %% [markdown]
# # Thesis Extensions: Leakage-Aware Churn Analytics
# Independent research notebook. Requires only randomdata.csv, not the paper notebook.
# A: controlled 2 × 2 ablation; B: label ambiguity and information diagnostics;
# C: robustness, equal-group weighting, and dependence-sensitive uncertainty.
# The observations are records, not verified independent customers or policies.

# %%
from pathlib import Path
from datetime import datetime, timezone
import os, sys, json, hashlib, platform, warnings
from zipfile import ZipFile, ZIP_DEFLATED
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from sklearn import __version__ as sklearn_version
from sklearn.model_selection import train_test_split, GroupShuffleSplit
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (roc_auc_score, accuracy_score, balanced_accuracy_score,
                             f1_score, average_precision_score, log_loss)
from scipy.special import xlogy

# Config: independently reproducible, including all random seeds.
ABLATION_SEEDS = [0,1,2,3,4]
REFERENCE_SEED = 10
N_PERMUTATIONS = 400
N_BOOTSTRAPS = 300
SEED_B = 20271019
SEED_C = 20271020
OUT = Path.cwd() / 'Thesis_Extensions_AB_C'
for sub in ('tables','figures','metadata'):
    (OUT/sub).mkdir(parents=True, exist_ok=True)
DATA_CANDIDATES = [Path.cwd()/'randomdata.csv', Path('/content/randomdata.csv'), Path('/mnt/data/randomdata.csv')]
data_path = next((p for p in DATA_CANDIDATES if p.exists()), None)
if data_path is None:
    try:
        from google.colab import files
        print('Upload randomdata.csv')
        uploaded = files.upload()
        data_path = Path('randomdata.csv')
    except ImportError:
        raise FileNotFoundError('Place randomdata.csv beside notebook before Run All.')
print('INPUT:', data_path)

def save_csv(frame, filename):
    path=OUT/'tables'/filename
    frame.to_csv(path, index=False, float_format='%.9g')
    print('Saved',path.name, 'rows',len(frame))
    return path

PALETTE={'LR':'#326EA8','RF':'#D07A47','GB':'#298F84','neutral':'#617083','dark':'#18324B'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,
                     'axes.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,
                     'figure.facecolor':'white','axes.facecolor':'white',
                     'svg.fonttype':'none','pdf.fonttype':42})
def save_fig(fig,name):
    for ext in ('png','svg','pdf'):
        fig.savefig(OUT/'figures'/f'{name}.{ext}',dpi=350 if ext=='png' else None,
                    bbox_inches='tight',pad_inches=0.12)
    plt.close(fig)
    print('Saved figure',name)

# %% [markdown]
# ## Input audit and shared grouping definition
# Group identity is based on six predictors after dropping BMI and identifiers,
# and is held fixed across BOTH levels of the BMI ablation.

# %%
df=pd.read_csv(data_path)
assert df.shape == (200000,12), f'Unexpected CSV shape: {df.shape}'
assert set(df.Churn.unique())=={'Yes','No'}
y = df.Churn.eq('Yes').astype(np.int8).to_numpy()
CATS = ['Claim Reason','Data confidentiality','Claim Request output']
NUMERIC_BASE=['Claim Amount','Category Premium','Premium/Amount Ratio']
PREDICTORS_NO_BMI = [c for c in df.columns if c not in
   {'Unnamed: 0','Customer Name','Customer_Address','Company Name','Churn','BMI'}]
X0 = df[PREDICTORS_NO_BMI].copy()
X1 = df[PREDICTORS_NO_BMI+['BMI']].copy()
group_hash = pd.util.hash_pandas_object(X0, index=False).to_numpy()
group_ids,group_uniques = pd.factorize(group_hash,sort=False)
NG=int(group_ids.max()+1)
assert NG==1769, f'Expected 1769 groups, got {NG}'
assert df['BMI'].le(24).eq(df.Churn.eq('Yes')).all()
g_sizes = np.bincount(group_ids,minlength=NG)
g_pos = np.bincount(group_ids,weights=y,minlength=NG)
assert np.all((g_pos>0)&(g_pos<g_sizes)), 'Each BMI-excluded group was expected to contain both labels.'
print('Records',len(df),'Positive prevalence',y.mean(),'Unique BMI-free groups',NG)
print('Group size (min/median/max):',g_sizes.min(),np.median(g_sizes),g_sizes.max())
sha=hashlib.sha256()
with open(data_path,'rb') as f:
    for chunk in iter(lambda:f.read(1024*1024),b''):
        sha.update(chunk)
dataset_sha=sha.hexdigest()

# %% [markdown]
# ## A: Controlled 2×2 ablation study
# Four factorial cells hold estimator family and hyperparameters constant.
# Random splits are stratified at the record level. Group-aware splits hold out
# 20% of distinct X-without-BMI groups. These are diagnostic, not temporal splits.

# %%
models={'LR':'Logistic Regression','RF':'Random Forest','GB':'Gradient Boosting'}
def build_model(key, seed):
    if key=='LR': return LogisticRegression(max_iter=400,random_state=seed)
    if key=='RF': return RandomForestClassifier(n_estimators=60,random_state=seed,n_jobs=4)
    if key=='GB': return GradientBoostingClassifier(n_estimators=60,random_state=seed)
    raise ValueError(key)

def fit_once(train_idx,test_idx,use_bmi,seed,keep_scores=False):
    xx=X1 if use_bmi else X0
    nums=NUMERIC_BASE+(['BMI'] if use_bmi else [])
    pp=ColumnTransformer([('categorical',OneHotEncoder(handle_unknown='ignore',sparse_output=False),CATS),
                          ('numeric',StandardScaler(),nums)])
    xt=pp.fit_transform(xx.iloc[train_idx]); xv=pp.transform(xx.iloc[test_idx])
    yt=y[train_idx]; yv=y[test_idx]
    stats=[]; scores_dict={}
    for key in models:
        mdl=build_model(key,seed)
        mdl.fit(xt,yt)
        prob=mdl.predict_proba(xv)[:,1]
        pred=(prob>=0.5).astype(int)
        stats.append({'model':key,'auc':roc_auc_score(yv,prob),
                      'accuracy':accuracy_score(yv,pred),
                      'balanced_accuracy':balanced_accuracy_score(yv,pred),
                      'f1_positive':f1_score(yv,pred,zero_division=0),
                      'average_precision':average_precision_score(yv,prob),
                      'positive_prevalence':float(yv.mean()),
                      'test_n':len(yv),'test_groups':len(np.unique(group_ids[test_idx]))})
        if keep_scores:scores_dict[key]=prob
    return stats,scores_dict

records=[]
for seed in ABLATION_SEEDS:
    rand_tr,rand_te=train_test_split(np.arange(len(y)),test_size=0.2,
                                   random_state=seed,stratify=y)
    grp_tr,grp_te=next(GroupShuffleSplit(n_splits=1,test_size=0.2,random_state=seed)
                       .split(X0,y,groups=group_hash))
    assert not np.intersect1d(group_ids[grp_tr],group_ids[grp_te]).size
    for split_name,tr,te in [('Random',rand_tr,rand_te),('Group-aware',grp_tr,grp_te)]:
        for use_bmi in (True,False):
            stats,_=fit_once(tr,te,use_bmi,seed)
            for d in stats:
                records.append(dict(seed=seed,split=split_name,
                                    bmi='Included' if use_bmi else 'Excluded',**d))
    print(f'Completed A seed {seed}: {len(records)} evaluation rows',flush=True)
abl=pd.DataFrame(records)
save_csv(abl,'A_ablation_all_seeds.csv')
A_summary=(abl.groupby(['split','bmi','model'],as_index=False)
           .agg(auc_mean=('auc','mean'),auc_sd=('auc','std'),
                balanced_accuracy_mean=('balanced_accuracy','mean'),
                accuracy_mean=('accuracy','mean'),f1_mean=('f1_positive','mean'),
                ap_mean=('average_precision','mean'),
                test_n_mean=('test_n','mean')))
save_csv(A_summary,'A_ablation_summary.csv')
print('\nABLATION SUMMARY (AUC):')
print(A_summary[['split','bmi','model','auc_mean','auc_sd']].round(4).to_string(index=False))
assert len(abl)==len(ABLATION_SEEDS)*4*3
assert abl.loc[abl.bmi.eq('Included'),'auc'].min() > 0.999, 'Unexpected BMI retained performance'

# %%
fig,axes=plt.subplots(1,2,figsize=(10,3.8),sharey=True)
for ax,bmi in zip(axes,['Included','Excluded']):
    wide=A_summary[A_summary.bmi.eq(bmi)].set_index(['split','model'])
    for i,mod in enumerate(models):
        a=[wide.loc[(s,mod),'auc_mean'] for s in ('Random','Group-aware')]
        err=[wide.loc[(s,mod),'auc_sd'] for s in ('Random','Group-aware')]
        ax.errorbar(np.array([0,1])+(i-1)*0.075,a,yerr=err,fmt='o-',
                    capsize=3,lw=1.8,color=PALETTE[mod],label=mod)
    ax.axhline(0.5,color=PALETTE['neutral'],ls='--',lw=1,alpha=.75)
    ax.set_xticks([0,1],['Random split','Group-aware split'])
    ax.set_xlim(-.25,1.25);ax.set_ylim(0.46,1.035)
    ax.set_title(f'BMI {bmi.lower()}')
    ax.grid(axis='y',alpha=.20)
axes[0].set_ylabel('AUC-ROC (mean ± SD)')
axes[1].legend(loc='center right',frameon=False,title='Classifier')
save_fig(fig,'E1_factorial_ablation_auc')

# %% [markdown]
# ## B: Label ambiguity and predictive information
# Calculate empirical H(Y), H(Y|X), and in-sample group-majority oracle accuracy.
# The oracle is deliberately optimistic and NOT an out-of-sample estimator.
# Compare the apparent information gain and oracle gain with an exchangeable-label
# permutation reference. These null comparisons assume label exchangeability;
# undocumented record dependence prevents population-level inference.

# %%
def entropy_binary(p):
    q=np.asarray(p,dtype=float)
    return -xlogy(q,q)-xlogy(1-q,1-q)

p=float(y.mean()); p_g=g_pos/g_sizes
H_y=float(entropy_binary(p))
H_cond=float(np.average(entropy_binary(p_g),weights=g_sizes))
I_nats=H_y-H_cond
oracle_accuracy=float(np.maximum(g_pos,g_sizes-g_pos).sum()/len(y))
baseline_accuracy=max(p,1-p)
heterogeneity=float(np.sum(g_sizes*(p_g-p)**2))
B_report={'records':len(y),'unique_vectors':NG,
          'conflicting_label_vectors':int(np.sum((g_pos>0)&(g_pos<g_sizes))),
          'positive_prevalence':p,'entropy_y_nats':H_y,
          'conditional_entropy_y_given_x_nats':H_cond,
          'empirical_information_gain_nats':I_nats,
          'empirical_information_gain_bits':I_nats/np.log(2),
          'global_majority_accuracy':baseline_accuracy,
          'in_sample_group_oracle_accuracy':oracle_accuracy,
          'oracle_gain_over_global_majority':oracle_accuracy-baseline_accuracy,
          'group_rate_min':float(p_g.min()),'group_rate_max':float(p_g.max()),
          'group_rate_sd_unweighted':float(np.std(p_g))}
save_csv(pd.DataFrame([B_report]),'B_information_and_oracle.csv')
print('B observed', {k:round(v,6) if isinstance(v,float) else v for k,v in B_report.items()})

rng=np.random.default_rng(SEED_B)
perms=[]
for b in range(N_PERMUTATIONS):
    yp=rng.permutation(y)
    gp=np.bincount(group_ids,weights=yp,minlength=NG)
    r=gp/g_sizes
    perms.append({'iteration':b,
        'null_information_gain_nats':H_y-float(np.average(entropy_binary(r),weights=g_sizes)),
        'null_oracle_accuracy':float(np.maximum(gp,g_sizes-gp).sum()/len(y)),
        'null_heterogeneity':float(np.sum(g_sizes*(r-p)**2))})
nulls=pd.DataFrame(perms)
save_csv(nulls,'B_permutation_reference.csv')
B_comparison=pd.DataFrame([
 {'diagnostic':'Information gain (nats)','observed':I_nats,
  'null_mean':nulls.null_information_gain_nats.mean(),
  'null_025':nulls.null_information_gain_nats.quantile(.025),
  'null_975':nulls.null_information_gain_nats.quantile(.975),
  'exceedance_fraction':(1+(nulls.null_information_gain_nats>=I_nats).sum())/(N_PERMUTATIONS+1)},
 {'diagnostic':'In-sample group oracle accuracy','observed':oracle_accuracy,
  'null_mean':nulls.null_oracle_accuracy.mean(),
  'null_025':nulls.null_oracle_accuracy.quantile(.025),
  'null_975':nulls.null_oracle_accuracy.quantile(.975),
  'exceedance_fraction':(1+(nulls.null_oracle_accuracy>=oracle_accuracy).sum())/(N_PERMUTATIONS+1)},
 {'diagnostic':'Between-group heterogeneity','observed':heterogeneity,
  'null_mean':nulls.null_heterogeneity.mean(),
  'null_025':nulls.null_heterogeneity.quantile(.025),
  'null_975':nulls.null_heterogeneity.quantile(.975),
  'exceedance_fraction':(1+(nulls.null_heterogeneity>=heterogeneity).sum())/(N_PERMUTATIONS+1)}])
save_csv(B_comparison,'B_observed_vs_permuted.csv')
print(B_comparison.round(6).to_string(index=False))
profile=pd.DataFrame({'group_id':np.arange(NG),'group_n':g_sizes,
                      'churn_yes_n':g_pos.astype(int),'churn_rate':p_g})
save_csv(profile,'B_group_label_profiles.csv')

# %%
fig,axes=plt.subplots(1,2,figsize=(10.5,3.6))
axes[0].hist(p_g,bins=np.linspace(0,1,31),color=PALETTE['LR'],alpha=.85)
axes[0].axvline(p,color=PALETTE['RF'],ls='--',label=f'Overall prevalence {p:.3f}')
axes[0].set(xlabel='Observed churn fraction per predictor vector',
            ylabel='Number of unique predictor vectors')
axes[0].legend(frameon=False,fontsize=8.5)
axes[0].set_title('(a) Label mixtures among 1,769 groups')
axes[1].hist(nulls.null_information_gain_nats,bins=28,color=PALETTE['neutral'],alpha=.85)
axes[1].axvline(I_nats,color=PALETTE['RF'],lw=2,label=f'Observed {I_nats:.4f}')
axes[1].set(xlabel='Apparent information gain (nats)',ylabel='Permutation count')
axes[1].legend(frameon=False,fontsize=8.5)
axes[1].set_title('(b) Exchangeable-label reference')
for ax in axes:ax.grid(axis='y',alpha=.15)
fig.tight_layout(w_pad=2)
save_fig(fig,'E2_label_ambiguity_and_information')

# %% [markdown]
# ## C: Split sensitivity and cluster-aware uncertainty
# Group-aware representative split (seed 10), trained afresh under the same
# estimator settings. Compare AUC weighted by records versus equal-total-weight
# for each unique predictor group. Bootstrap at row and group level separately.
# Groups here are identical feature vectors, NOT verified independent persons.

# %%
tr,te=next(GroupShuffleSplit(n_splits=1,test_size=0.2,random_state=REFERENCE_SEED)
           .split(X0,y,groups=group_hash))
assert len(tr)==157620 and len(te)==42380,'Representative split mismatch; check input/group construction'
reference_metrics,scores=fit_once(tr,te,False,REFERENCE_SEED,keep_scores=True)
ref_table=pd.DataFrame(reference_metrics)
ref_table.insert(0,'seed',REFERENCE_SEED)
save_csv(ref_table,'C_representative_split_metrics.csv')
yte=y[te]
gte=group_ids[te]
unique_test,local_g=np.unique(gte,return_inverse=True)
num_test_groups=len(unique_test)
local_counts=np.bincount(local_g)
equal_group_w=1.0/local_counts[local_g]
rng=np.random.default_rng(SEED_C)
row_boot_index=[rng.integers(0,len(te),size=len(te)) for _ in range(N_BOOTSTRAPS)]
# Cluster bootstrap: resample the feature-vector groups with replacement;
# weight original observations by the number of group draws.
group_mults=[np.bincount(rng.integers(0,num_test_groups,size=num_test_groups),
                         minlength=num_test_groups) for _ in range(N_BOOTSTRAPS)]
C_rows=[]
for name,score in scores.items():
    observed=roc_auc_score(yte,score)
    equal=roc_auc_score(yte,score,sample_weight=equal_group_w)
    row_vals=np.array([roc_auc_score(yte[idx],score[idx])
                       for idx in row_boot_index])
    group_vals=np.array([roc_auc_score(yte,score,sample_weight=mult[local_g])
                         for mult in group_mults])
    C_rows.append({'model':name,'representative_seed':REFERENCE_SEED,
                   'test_records':len(te),'test_unique_groups':num_test_groups,
                   'auc_record_weighted':observed,'auc_equal_group_weighted':equal,
                   'bootstrap_row_ci_low':np.quantile(row_vals,.025),
                   'bootstrap_row_ci_high':np.quantile(row_vals,.975),
                   'bootstrap_group_ci_low':np.quantile(group_vals,.025),
                   'bootstrap_group_ci_high':np.quantile(group_vals,.975),
                   'bootstrap_row_sd':np.std(row_vals,ddof=1),
                   'bootstrap_group_sd':np.std(group_vals,ddof=1)})
    print('Completed C bootstrap:',name, flush=True)
C_table=pd.DataFrame(C_rows)
save_csv(C_table,'C_group_weighting_and_bootstrap.csv')
print('\nC SENSITIVITY:\n',C_table.round(5).to_string(index=False))

# %%
fig,axes=plt.subplots(1,2,figsize=(10.6,3.6))
for model in models:
    z=abl[(abl.model==model)&(abl.bmi=='Excluded')]
    for j,split in enumerate(['Random','Group-aware']):
        vals=z.loc[z.split==split,'auc'].to_numpy()
        axes[0].scatter(np.full(len(vals),j+(list(models).index(model)-1)*.14),vals,
                        color=PALETTE[model],s=28,alpha=.80,label=model if j==0 else None)
axes[0].axhline(.5,color=PALETTE['neutral'],ls='--')
axes[0].set_xticks([0,1],['Random split','Group-aware split'])
axes[0].set_ylabel('AUC-ROC (BMI excluded)')
axes[0].set_ylim(.46,.54)
axes[0].set_title('(a) Variation across five held-out splits')
axes[0].legend(frameon=False,ncol=3,fontsize=9,loc='upper center')
xx=np.arange(3)
for j,(_,r) in enumerate(C_table.iterrows()):
    axes[1].plot([j-.15,j+.15],[r.auc_record_weighted,r.auc_equal_group_weighted],
                 color=PALETTE['neutral'],lw=1.5,alpha=.8)
    axes[1].scatter(j-.15,r.auc_record_weighted,marker='o',color=PALETTE['LR'],s=40,
                    label='Record-weighted (group-bootstrap CI)' if j==0 else None)
    axes[1].scatter(j+.15,r.auc_equal_group_weighted,marker='s',color=PALETTE['RF'],s=40,
                    label='Equal group-weighted' if j==0 else None)
    axes[1].errorbar(j-.15,r.auc_record_weighted,
                     yerr=[[r.auc_record_weighted-r.bootstrap_group_ci_low],
                           [r.bootstrap_group_ci_high-r.auc_record_weighted]],
                     fmt='none',capsize=3,lw=1,color=PALETTE['LR'])
axes[1].legend(frameon=False,fontsize=8.5)
axes[1].axhline(.5,color=PALETTE['neutral'],ls='--')
axes[1].set_xticks(xx,list(models))
axes[1].set_ylabel('Representative-split AUC-ROC')
axes[1].set_title('(b) Group weighting and group-bootstrap CI')
for ax in axes: ax.grid(axis='y',alpha=.14)
fig.tight_layout(w_pad=2)
save_fig(fig,'E3_split_robustness_and_group_uncertainty')

# %% [markdown]
# ## Thesis result manifest and reproducibility checks
# Separate descriptive sample evidence from statistical generalization.

# %%
checks={
 'dataset_has_200000_rows':len(df)==200000,
 'correct_unique_groups_without_BMI':NG==1769,
 'all_groups_have_both_labels':bool(np.all((g_pos>0)&(g_pos<g_sizes))),
 'BMI_determines_label_in_observed_dataset':bool(df.BMI.le(24).eq(df.Churn.eq('Yes')).all()),
 'full_ablation_completed':len(abl)==len(ABLATION_SEEDS)*4*len(models),
 'BMI_retained_AUC_approximately_one':bool(abl.loc[abl.bmi.eq('Included'),'auc'].min()>.999),
 'representative_split_matches_paper':len(tr)==157620 and len(te)==42380,
 'uncertainty_for_three_models':len(C_table)==3,
}
manifest={
 'project':'Thesis extension A+B+C - leakage-aware churn prediction',
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'data_file':data_path.name,'dataset_sha256':dataset_sha,
 'rows':len(df),'feature_vector_groups_excluding_BMI':NG,
 'experimental_units_warning':'Record-level observations; independent policyholder IDs and prospective timing NOT established.',
 'ablations':{'seeds':ABLATION_SEEDS,'group_definition':'Predictor vector excluding BMI in ALL factorial conditions',
              'random':'stratified record-wise 80/20','group':'GroupShuffleSplit 20% of unique groups',
              'estimators':{'LR':'LogisticRegression(max_iter=400)',
                            'RF':'RandomForestClassifier(n_estimators=60)',
                            'GB':'GradientBoostingClassifier(n_estimators=60)'}},
 'label_permutation':{'replicates':N_PERMUTATIONS,'seed':SEED_B,
  'interpretation':'Hypothetical exchangeable-label reference, not unconditional customer-level inference'},
 'uncertainty':{'seed':REFERENCE_SEED,'replicates':N_BOOTSTRAPS,
                'seed_bootstrap':SEED_C,
                'groups':'identical feature vectors; group bootstrap sensitivity, not validated customer cluster sampling'},
 'versions':{'python':platform.python_version(),'numpy':np.__version__,
             'pandas':pd.__version__,'sklearn':sklearn_version},
 'checks':checks}
with open(OUT/'metadata'/'experiment_manifest.json','w') as f: json.dump(manifest,f,indent=2)
assert all(checks.values()),checks
print('ALL VALIDATION CHECKS PASSED:',len(checks))

# %%
# A compact textual reference, intended for author interpretation, not auto-generated claims.
A0=A_summary[(A_summary.bmi=='Excluded')].sort_values(['split','model'])
B_null=B_comparison.set_index('diagnostic')
report=f'''# Thesis Extensions: Master Results and Interpretation Boundaries\n\nGenerated from dataset SHA-256: `{dataset_sha}`.\n\n## A. Factorial ablation (5 seeds)\n\nBoth predictor inclusion and split strategy were manipulated separately; groups for group-aware splitting were ALWAYS computed without BMI. AUC summaries:\n\n{A_summary[['split','bmi','model','auc_mean','auc_sd']].round(6).to_markdown(index=False)}\n\n**Interpretation:** BMI retained performance tests possible label encoding; random vs group split comparisons reveal sensitivity to exact predictor-vector overlap. The splits are not chronological or external.\n\n## B. Information and label ambiguity\n\n- Groups with both churn labels: {B_report['conflicting_label_vectors']}/{NG}.\n- H(Y) = {H_y:.6f} nats; empirical H(Y|X) = {H_cond:.6f} nats; apparent I(X;Y) = {I_nats:.6f} nats.\n- Global majority accuracy = {baseline_accuracy:.6f}; in-sample group-label oracle accuracy = {oracle_accuracy:.6f}; gain = {oracle_accuracy-baseline_accuracy:.6f}.\n- Information-gain permutation reference: mean {B_null.loc['Information gain (nats)','null_mean']:.6f}, 95% simulation interval [{B_null.loc['Information gain (nats)','null_025']:.6f}, {B_null.loc['Information gain (nats)','null_975']:.6f}].\n\n**Interpretation:** The group-majority oracle is optimized on observed labels and cannot be advertised as a population Bayes upper bound. A positive raw empirical information gain is expected under finite-sample noise; compare it with the permutation reference. Exchangeability may be unrealistic if records are dependent.\n\n## C. Robustness / uncertainty on representative split\n\n{C_table.round(6).to_markdown(index=False)}\n\n**Interpretation:** Equal-group weighting changes the estimand from a random record to an equal contribution from each observed feature group. Resampling feature-vector groups checks a form of dependence sensitivity, NOT verified customer-level uncertainty. Raw row and group bootstrap intervals use {N_BOOTSTRAPS} resamples; do not replace the paper's CI without explicitly updating its methodology.\n\n## Critical limitations\n\n1. The Kaggle source does not document a verified policyholder or policy ID, feature availability time, intervention outcomes, or external deployment data.\n2. BMI's deterministic label association alone cannot prove temporal leakage.\n3. Scenario A/B in the original paper changed both BMI and splitting; this factorial experiment isolates those protocol choices more cleanly.\n4. The notebook is a dataset-specific empirical assessment, not proof that insurance churn is inherently unpredictable.\n5. No benefit from retention campaigns can be inferred from this dataset.\n\n## Figures\n\n- E1_factorial_ablation_auc (A): AUC across four configurations.\n- E2_label_ambiguity_and_information (B): mixed-label groups and permutation reference.\n- E3_split_robustness_and_group_uncertainty (C): split variability and group-weighting uncertainty.\n\n## Reproduction\n\nPlace `randomdata.csv` next to `thesis_extensions_AB_C.ipynb`, then run all cells. CSV and figure outputs are written to `Thesis_Extensions_AB_C/tables` and `Thesis_Extensions_AB_C/figures`. No core-paper notebook imports are needed.\n'''
(OUT/'MASTER_RESULTS.md').write_text(report,encoding='utf-8')
print('\nEXPERIMENT FINISHED: all tables, figures, and documentation saved to',OUT)
