# Thesis demo: Leakage-aware churn analytics

Streamlit dashboard for **read-only scientific demonstration** of the ICICC 2027 churn paper and standalone thesis extensions A+B+C. It does **not** train models at runtime and does **not** estimate individual customer churn or retention uplift.

## Quick start (Windows, VS Code, or macOS/Linux)

1. Extract the **whole** ZIP into a folder and open a terminal in that folder.
2. Create a fresh virtual environment (optional but recommended):

   Windows PowerShell:
   ```powershell
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

   macOS/Linux:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```
3. Install dependencies and start the app:
   ```bash
   python -m pip install -r requirements.txt
   python -m streamlit run app.py
   ```
4. Streamlit opens in your browser, normally at `http://localhost:8501`.

Run the self-check before the demo:
```bash
python preflight.py
```

## Tabs / presentation flow

1. **Overview**: core research question and four-cell evidence summary.
2. **Data audit**: suspicious BMI association, duplicate-vector rates, mixed label groups.
3. **Controlled ablation (A)**: filter model, compare all four protocols, show AUC uncertainty.
4. **Information sufficiency (B)**: entropy, in-sample oracle, 400-permutation reference.
5. **Robustness (C)**: BMI-excluded AUC across five seeds; record/group weighting, group-bootstrap sensitivity.
6. **Monetary segmentation**: premium categories and observed churn, without claiming CLV or retention ROI.
7. **Methods & downloads**: provenance, warnings and raw aggregate artifact downloads.

## Contents

- `app.py`: Streamlit interface using precomputed tables and plots (no model retraining).
- `assets/tables/`: checked extension CSVs from `thesis_extensions_AB_C.ipynb`.
- `assets/figures/`: original research plots, including core Figures 2–5 and thesis Figures E1–E3.
- `assets/metadata/experiment_manifest.json`: input CSV fingerprint, experiment seeds and software versions.
- `assets/metadata/core_summary.json`: manuscript-level constants and category summary audited against the source CSV.
- `preflight.py`: dependency-free checks for bundle completeness and arithmetic consistency.
- `.streamlit/config.toml`: theme.

**No original `randomdata.csv` is included.** The app works offline after dependencies are installed. All charts are computed from small precomputed aggregate tables. To re-run any scientific experiment, use the independent thesis notebook delivered separately with the Kaggle CSV, not this demo.

## Interpretation guardrails

- Records are not verified independent customers or policies; their provenance and timing are undocumented.
- BMI is a *suspected deterministic outcome proxy*, not proven temporal leakage.
- Same predictor vectors in random train/test splits do not necessarily inflate AUC in this dataset: the factorized experiment showed chance performance once BMI was removed.
- Empirical conditional entropy and the in-sample oracle are not population Bayes bounds. Permutations assume label exchangeability.
- The group bootstrap groups identical observed feature vectors, **not** independent policyholders. Do not interpret its interval as external or customer-level confidence.
- K-means matches Medical versus three other premium categories. It is descriptive and does not validate retention profitability or causality.
- All model comparisons and null findings are conditional on this particular dataset, splits and model families.

## Source

Customer Churn Dataset for Life Insurance Industry, Kaggle: https://www.kaggle.com/datasets/usmanfarid/customer-churn-dataset-for-life-insurance-industry

## Runtime testing note

The scientific data consistency and Python compilation checks were run in the creation environment. That environment does not have Streamlit installed and cannot reach the Python package index; therefore an actual live browser launch of Streamlit must be tested locally after `pip install`.
