"""Thesis demonstration: leakage-aware life-insurance churn analytics.

All plots are based on PRECOMPUTED, checked aggregate outputs from the core
paper and the standalone A+B+C thesis experiment bundle. This application
never loads raw customer records, trains models, or outputs individual churn
risk estimates.

Run: streamlit run app.py
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "assets" / "tables"
FIGURES = ROOT / "assets" / "figures"
META = ROOT / "assets" / "metadata"
NAVY = "#14334A"
BLUE = "#3979A5"
TEAL = "#168F89"
ORANGE = "#D07A4A"
PURPLE = "#7564A7"
GREY = "#657687"
BG = "#F6F9FB"
MODELS = {"LR": "Logistic Regression", "RF": "Random Forest", "GB": "Gradient Boosting"}

st.set_page_config(
    page_title="Churn Model Reliability | Thesis Demo",
    page_icon="🔎",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
  .block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1370px; }
  h1, h2, h3 { color: #14334A; letter-spacing: -.023em; }
  h1 { font-size: 2.1rem !important; font-weight: 750 !important; }
  h2 { font-size: 1.45rem !important; padding-top: .25rem !important; }
  div[data-testid="stMetric"] { background: #F6F9FB; border: 1px solid #E4EDF1;
      padding: 1rem 1.1rem; border-radius: 13px; }
  div[data-testid="stMetricLabel"] { color: #536D80; }
  div[data-testid="stMetricValue"] { color: #14334A; }
  [data-testid="stSidebar"] { background: #F4F8FA; border-right: 1px solid #E0EAF0; }
  .eyebrow { color: #167D84; font-size: .80rem; font-weight: 700;
      letter-spacing: .12em; text-transform: uppercase; margin-bottom: .3rem; }
  .deck { color: #567083; font-size: 1rem; line-height: 1.65; margin-top: .2rem; }
  .hint { color: #677B88; font-size: .86rem; }
  .rule { height: 1px; background: #E4EDF1; margin: 1rem 0; }
  .hero { padding: 1rem 1.3rem 1.15rem; background: linear-gradient(110deg, #EDF5F9 0%, #F8FBFC 100%);
      border:1px solid #DDECF1; border-radius: 15px; margin: .6rem 0 1.35rem; }
  .verdict { border-left:4px solid #C9844E; background:#FBF7F1; padding:.85rem 1.05rem;
      border-radius: 0 9px 9px 0; margin: .7rem 0 1rem; line-height:1.65; }
  .mini { font-size:.85rem; color: #627785; }
</style>
""", unsafe_allow_html=True)

@st.cache_data(show_spinner=False)
def get_results() -> dict:
    files = {
        "A_all": "A_ablation_all_seeds.csv",
        "A_summary": "A_ablation_summary.csv",
        "B_groups": "B_group_label_profiles.csv",
        "B_information": "B_information_and_oracle.csv",
        "B_perm": "B_permutation_reference.csv",
        "B_obs": "B_observed_vs_permuted.csv",
        "C_bootstrap": "C_group_weighting_and_bootstrap.csv",
        "C_representative": "C_representative_split_metrics.csv",
    }
    tables = {name: pd.read_csv(DATA / filename) for name, filename in files.items()}
    tables["core"] = json.loads((META / "core_summary.json").read_text(encoding="utf-8"))
    tables["manifest"] = json.loads((META / "experiment_manifest.json").read_text(encoding="utf-8"))
    return tables

D = get_results()
CORE = D["core"]

def chart_base(height: int = 365, legend: bool = True, zoom: bool = False) -> dict:
    return dict(
        template="plotly_white",
        height=height,
        font=dict(family="Arial, sans-serif", size=13, color=NAVY),
        margin=dict(l=30, r=18, t=35, b=45),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        showlegend=legend,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0),
        xaxis=dict(showgrid=False, linecolor="#BCCCD7"),
        yaxis=dict(gridcolor="#E7EFF3", zeroline=False),
        hoverlabel=dict(bgcolor="white", font_size=12),
    )

def figure_show(fig: go.Figure, key: str) -> None:
    st.plotly_chart(fig, use_container_width=True, config={"displaylogo": False, "responsive": True}, key=key)

def from_path_image(filename: str, caption: str = "") -> None:
    target = FIGURES / filename
    if target.exists():
        st.image(str(target), caption=caption, use_container_width=True)

def core_note() -> None:
    st.markdown("""<div class="verdict"><b>Validation conclusion:</b> The evaluated BMI-excluded predictors do not
    provide reliable out-of-sample churn discrimination under the tested protocols.
    This is <b>not</b> evidence that churn is universally unpredictable or that retention programs cannot work.</div>""", unsafe_allow_html=True)

def section_title(name: str, summary: str) -> None:
    st.markdown(f'<div class="eyebrow">THESIS DEMONSTRATION</div>', unsafe_allow_html=True)
    st.title(name)
    st.markdown(f'<p class="deck">{summary}</p>', unsafe_allow_html=True)

st.sidebar.markdown("### RESEARCH CONSOLE")
st.sidebar.caption("Leakage-aware evaluation · precomputed scientific evidence")
page = st.sidebar.radio(
    "Explore", [
        "01 · Overview", "02 · Data audit", "03 · Controlled ablation",
        "04 · Information sufficiency", "05 · Robustness",
        "06 · Monetary segmentation", "07 · Methods & downloads"
    ], label_visibility="collapsed"
)
st.sidebar.divider()
st.sidebar.caption("CORE: ICICC 2027 study")
st.sidebar.caption("EXTENSIONS: A + B + C · 5 ablation seeds")
st.sidebar.caption("No model training or personal risk scoring")

if page.startswith("01"):
    section_title(
        "Can this churn model be trusted?",
        "A research-first view of model validity, information quality, and the limits of retention-related claims."
    )
    st.markdown('<div class="hero"><b>The central finding</b><div class="deck">An AUC of 1.000 did not survive exclusion of a deterministic BMI–churn proxy. A controlled ablation isolates the role of BMI from the train/test splitting choice, and subsequent tests assess whether the remaining observed predictors contain meaningful empirical information.</div></div>', unsafe_allow_html=True)
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Records (not verified customers)", f"{CORE['record_count']:,}")
    m2.metric("Original AUC with BMI", "1.000")
    m3.metric("BMI-excluded AUC", "≈ 0.500")
    m4.metric("Unique groups without BMI", f"{CORE['unique_predictor_vectors_without_bmi']:,}")
    core_note()
    st.subheader("Evidence chain")
    c1,c2,c3=st.columns(3)
    with c1:
        st.markdown("**1 · Audit suspicious predictors**")
        st.write("BMI partitions all observed churn labels. After excluding BMI, all 1,769 distinct predictor vectors contain both label classes.")
    with c2:
        st.markdown("**2 · Factor out evaluation choices**")
        st.write("Four protocol cells compare BMI included/excluded and random/group-aware splitting. The marked drop in AUC tracks BMI exclusion.")
    with c3:
        st.markdown("**3 · Check uncertainty and decisions**")
        st.write("Permutation references and group-resampled sensitivity remain consistent with a near-chance finding; monetary clusters do not show retention uplift.")
    st.divider()
    st.subheader("The controlled experiment")
    plot = go.Figure()
    ab = D["A_summary"]
    for code,color in [("LR",BLUE),("RF",TEAL),("GB",ORANGE)]:
        temp = ab[ab.model.eq(code)].copy()
        temp["condition"] = temp["bmi"] + " · " + temp["split"]
        order = ["Included · Random", "Included · Group-aware", "Excluded · Random", "Excluded · Group-aware"]
        temp = temp.set_index("condition").reindex(order).reset_index()
        plot.add_trace(go.Scatter(x=temp.condition, y=temp.auc_mean, mode="lines+markers",
                error_y=dict(type="data", array=temp.auc_sd, visible=True, thickness=1.3, width=3),
                name=MODELS[code], line=dict(color=color, width=2), marker=dict(size=9),
                hovertemplate="%{x}<br>AUC %{y:.4f}<extra>%{fullData.name}</extra>"))
    plot.update_layout(**chart_base(360))
    plot.update_yaxes(range=[0.0,1.06], title="Mean AUC-ROC (five seeds)")
    plot.update_xaxes(title=None)
    figure_show(plot,"overview_ablation")
    st.caption("Full-scale axis. These results are record-level tests, not independent policyholder evaluation. Error bars are ± one SD across five seeds.")

elif page.startswith("02"):
    section_title("01 / Data audit", "Identify outcome proxies, repeated predictor vectors, and ambiguity before trusting classification metrics.")
    m1,m2,m3,m4=st.columns(4)
    m1.metric("Original records", "200,000")
    m2.metric("Unique vectors with BMI", "19,373")
    m3.metric("Unique vectors without BMI", "1,769")
    m4.metric("Mixed-label groups", "1,769 / 1,769")
    st.warning("These are repeated feature vectors, not proven duplicate people or policies. The unit of observation and feature timestamps are undocumented.")
    t1,t2=st.tabs(["BMI outcome proxy", "Repeated feature patterns"])
    with t1:
        st.markdown("**Observed deterministic BMI–churn relationship**")
        q=go.Figure()
        q.add_trace(go.Bar(x=["BMI ≤ 24", "BMI ≥ 25"], y=[127272, 72728],
                    marker_color=[ORANGE,BLUE], text=["127,272 Churn = Yes", "72,728 Churn = No"],
                    textposition="outside", hovertemplate="%{x}: %{y:,} records<extra></extra>"))
        q.update_layout(**chart_base(325,legend=False))
        q.update_yaxes(range=[0,145000],title="Records")
        figure_show(q,"audit_bmi")
        st.info("A deterministic target proxy is an audit warning. Without feature provenance and prediction timing, it cannot be conclusively identified as temporal data leakage.")
        with st.expander("View Figure 2 from the core paper"):
            from_path_image("Figure_2_Data_Audit.png","Core audit: mutual information and BMI–churn correspondence")
    with t2:
        fractions = [CORE["redundant_fraction_with_bmi"]*100, CORE["redundant_fraction_without_bmi"]*100]
        b=go.Figure(go.Bar(x=["With BMI", "Without BMI"],y=fractions,marker_color=[BLUE,TEAL],
                 text=[f"{v:.2f}%" for v in fractions],textposition="outside"))
        b.update_layout(**chart_base(320,legend=False))
        b.update_yaxes(range=[0,107],title="Redundant-row fraction (%)")
        figure_show(b,"audit_redundancy")
        st.markdown(r"**Definition:** For $N$ records and $U$ unique predictor vectors, redundant-row fraction $=(N-U)/N$ after retaining one representative per vector.")
        st.write("With BMI: 180,627 redundant occurrences. Without BMI: 198,231 redundant occurrences. Each BMI-excluded group contains observations labeled both Yes and No.")
        g = D["B_groups"]
        left,right=st.columns(2)
        with left:
            h=go.Figure(go.Histogram(x=g.group_n,nbinsx=38,marker_color=BLUE))
            h.update_layout(**chart_base(330,legend=False))
            h.update_xaxes(title="Records per identical predictor group")
            h.update_yaxes(title="Number of groups")
            figure_show(h,"audit_groupsizes")
        with right:
            r=go.Figure(go.Scatter(x=g.group_n,y=g.churn_rate,mode="markers",
                marker=dict(color=TEAL,size=6,opacity=0.5),showlegend=False))
            r.add_hline(y=CORE["churn_yes"]/CORE["record_count"], line_dash="dash", line_color=GREY)
            r.update_layout(**chart_base(330,legend=False))
            r.update_xaxes(title="Records per group")
            r.update_yaxes(title="Within-group observed churn fraction")
            figure_show(r,"audit_grouprates")

elif page.startswith("03"):
    section_title("02 / Controlled ablation", "A two-factor experiment: BMI inclusion and train/test splitting, with three fixed model families.")
    st.markdown("The same BMI-excluded predictor-vector definition was used for grouping in both BMI conditions. Five seeds (0–4) were used for each configuration; the original paper's ten-seed analysis remains a separate result.")
    choice=st.selectbox("Classifier", list(MODELS), format_func=lambda x: MODELS[x])
    a=D["A_summary"]
    tab=a[a.model.eq(choice)].copy()
    rows=[]
    for x in ("Included","Excluded"):
        for s in ("Random","Group-aware"):
            r=tab[(tab.bmi==x)&(tab.split==s)].iloc[0]
            rows.append(dict(protocol=f"BMI {x.lower()} · {s}",auc=float(r.auc_mean),sd=float(r.auc_sd),
                             balanced_accuracy=float(r.balanced_accuracy_mean),f1=float(r.f1_mean)))
    tbl=pd.DataFrame(rows)
    c1,c2,c3,c4=st.columns(4)
    for c,r in zip((c1,c2,c3,c4),rows):
        with c:
            st.metric(r["protocol"], f"{r['auc']:.4f}")
    scale=st.radio("AUC axis",["Full scale (0–1)","Focus near chance (0.48–0.52)"],horizontal=True)
    fig=go.Figure()
    colormap=[BLUE,TEAL,ORANGE,PURPLE]
    fig.add_trace(go.Bar(x=tbl.protocol,y=tbl.auc,marker_color=colormap,
                    error_y=dict(type="data",array=tbl.sd,visible=True,thickness=1.5),
                    text=[f"{x:.4f}" for x in tbl.auc],textposition="outside",
                    hovertemplate="%{x}<br>Mean AUC: %{y:.6f}<extra></extra>"))
    fig.add_hline(y=0.5, line_dash="dash",line_color=GREY,annotation_text="Chance 0.5")
    fig.update_layout(**chart_base(380,legend=False))
    fig.update_yaxes(range=[0,1.09] if scale.startswith("Full") else [0.48,0.52], title="AUC-ROC, mean of five seeds")
    figure_show(fig,"ablation_choose")
    if not scale.startswith("Full"):
        st.caption("Focused axis only: configurations with BMI included (AUC = 1) are intentionally outside this zoomed plot.")
    st.dataframe(tbl.rename(columns={"protocol":"Configuration","auc":"Mean AUC","sd":"AUC SD","balanced_accuracy":"Balanced accuracy","f1":"Positive-class F1"}).style.format(precision=4),hide_index=True,use_container_width=True)
    st.info("With BMI retained, every evaluated configuration achieved AUC 1.000. Without BMI, AUC stayed near 0.500 for both splitting procedures. This does not prove BMI was available only after the outcome, or establish generalization to another dataset.")
    with st.expander("View thesis figure E1"):
        from_path_image("E1_factorial_ablation_auc.png")

elif page.startswith("04"):
    section_title("03 / Information sufficiency", "Assess whether the remaining predictor vectors carry reproducible label information beyond finite-sample variation.")
    summary=D["B_information"].iloc[0]
    observation=D["B_obs"]
    null=D["B_perm"]
    info=observation[observation.diagnostic.eq("Information gain (nats)")].iloc[0]
    c1,c2,c3,c4=st.columns(4)
    c1.metric("H(Y) · nats",f"{summary.entropy_y_nats:.6f}")
    c2.metric("H(Y | X) · nats",f"{summary.conditional_entropy_y_given_x_nats:.6f}")
    c3.metric("Empirical IG · nats",f"{summary.empirical_information_gain_nats:.6f}")
    c4.metric("Permutation exceedance",f"{info.exceedance_fraction:.3f}")
    st.markdown("**Observed information gain against a 400-permutation label-shuffling reference**")
    fig=go.Figure()
    fig.add_trace(go.Histogram(x=null.null_information_gain_nats,marker_color=BLUE,opacity=.76,
                               nbinsx=32,name="Shuffled labels"))
    fig.add_vline(x=float(info.observed),line_color=ORANGE,line_width=2.5,
                  annotation_text="Observed IG",annotation_position="top right")
    fig.update_layout(**chart_base(360,legend=False))
    fig.update_xaxes(title="Empirical information gain (nats)")
    fig.update_yaxes(title="Permutation replicates")
    figure_show(fig,"information_perm")
    cc1,cc2=st.columns(2)
    cc1.metric("Global majority accuracy",f"{summary.global_majority_accuracy:.4%}")
    cc2.metric("In-sample group oracle accuracy",f"{summary.in_sample_group_oracle_accuracy:.4%}",
               delta=f"+{summary.oracle_gain_over_global_majority*100:.4f} percentage points",delta_color="off")
    st.caption(f"Null information-gain mean: {info.null_mean:.6f} nats; empirical permutation reference (2.5th–97.5th): [{info.null_025:.6f}, {info.null_975:.6f}].")
    st.warning("This oracle uses the SAME records on which it is evaluated. It is not an out-of-sample model or an upper bound on achievable population prediction. Shuffled-label inference also assumes exchangeability that may not hold among dependent records.")
    with st.expander("View thesis figure E2"):
        from_path_image("E2_label_ambiguity_and_information.png")

elif page.startswith("05"):
    section_title("04 / Robustness & uncertainty", "Inspect sensitivity to split choice, record/group weighting, and bootstrap resampling unit.")
    sel=st.selectbox("Model for detailed uncertainty",list(MODELS),format_func=lambda x: MODELS[x])
    all_seeds=D["A_all"]
    line_data=all_seeds[(all_seeds.bmi=="Excluded")&(all_seeds.model==sel)].copy()
    fig=go.Figure()
    for split,col in [("Random",BLUE),("Group-aware",TEAL)]:
        t=line_data[line_data.split.eq(split)].sort_values("seed")
        fig.add_trace(go.Scatter(x=t.seed,y=t.auc,mode="lines+markers",line=dict(color=col,width=2),
                                 marker=dict(size=9),name=split))
    fig.add_hline(y=0.5,line_dash="dash",line_color=GREY)
    fig.update_layout(**chart_base(335))
    fig.update_yaxes(title="AUC-ROC · BMI excluded",range=[0.485,0.515])
    fig.update_xaxes(title="Ablation split seed",dtick=1)
    figure_show(fig,"robustness_seed")
    st.caption("Axis deliberately zoomed to reveal small differences around chance level. These are five ablation seeds, not the core paper's ten seeds.")

    row=D["C_bootstrap"][D["C_bootstrap"].model.eq(sel)].iloc[0]
    st.subheader("Record vs feature-group sensitivity · seed 10")
    u1,u2,u3=st.columns(3)
    u1.metric("Record-weighted AUC",f"{row.auc_record_weighted:.4f}")
    u2.metric("Equal-group-weighted AUC",f"{row.auc_equal_group_weighted:.4f}")
    u3.metric("Feature groups in test set",f"{int(row.test_unique_groups):,}")
    intervals=[
        ("Record bootstrap",float(row.bootstrap_row_ci_low),float(row.bootstrap_row_ci_high),BLUE),
        ("Feature-group bootstrap",float(row.bootstrap_group_ci_low),float(row.bootstrap_group_ci_high),ORANGE),
    ]
    p=go.Figure()
    for label,lo,hi,color in intervals:
        center=float(row.auc_record_weighted)
        p.add_trace(go.Scatter(x=[center],y=[label],mode="markers",name=label,
            marker=dict(color=color,size=12),
            error_x=dict(type="data",symmetric=False,array=[hi-center],arrayminus=[center-lo],
                         thickness=2.2,width=9,color=color),
            hovertemplate=f"{label}<br>Interval [{lo:.4f}, {hi:.4f}]<extra></extra>"))
    p.add_vline(x=0.5,line_dash="dash",line_color=GREY,annotation_text="Chance 0.500")
    p.update_layout(**chart_base(255,legend=False))
    p.update_xaxes(range=[0.485,0.515],title="AUC-ROC (zoomed to chance-level region)")
    p.update_yaxes(showgrid=False)
    figure_show(p,"robustness_ci")
    st.warning("Both bootstrap approaches use 300 resamples of a single seed-10 partition. Group-bootstrap resamples identical feature-vector groups, NOT verified customers or policies. Intervals must not be interpreted as external validation.")
    with st.expander("View thesis figure E3"):
        from_path_image("E3_split_robustness_and_group_uncertainty.png")

elif page.startswith("06"):
    section_title("05 / Exploratory monetary segmentation", "A descriptive clustering result, not a demonstration of higher retention efficiency or profit.")
    core_groups=pd.DataFrame(CORE["premium_categories"])
    core_groups["churn_rate"] = core_groups.churn_yes / core_groups.records
    c1,c2,c3=st.columns(3)
    c1.metric("Best k among 2–8", "2")
    c2.metric("Silhouette · sample", "≈ 0.83")
    c3.metric("Davies–Bouldin · full data", "≈ 0.253")
    st.markdown("**K-means exactly recovers a binary grouping:** Medical versus Travel + Phone + Other. It does not discover structure beyond that existing premium-category split.")
    a,b=st.columns(2)
    with a:
        fig=go.Figure(go.Bar(x=core_groups.category,y=core_groups.premium,marker_color=[ORANGE,BLUE,BLUE,BLUE],
                      text=core_groups.premium.map(lambda x:f"{x:,}"),textposition="outside"))
        fig.update_layout(**chart_base(330,legend=False))
        fig.update_yaxes(title="Category Premium (source units)",range=[0,16000])
        figure_show(fig,"money_premium")
    with b:
        fig=go.Figure(go.Bar(x=core_groups.category,y=core_groups.churn_rate*100,
                      marker_color=[ORANGE,BLUE,BLUE,BLUE],text=[f"{x:.2f}%" for x in core_groups.churn_rate*100],
                      textposition="outside"))
        fig.update_layout(**chart_base(330,legend=False))
        fig.update_yaxes(title="Observed churn rate (%)",range=[0,72])
        figure_show(fig,"money_churn")
    coretable=pd.DataFrame(CORE["cluster_summary"])
    coretable=coretable.rename(columns={"cluster":"Cluster","name":"Category grouping","records":"Records","mean_premium":"Mean Category Premium","churn_rate":"Observed churn rate"})
    coretable["Observed churn rate"]*=100
    st.dataframe(coretable.style.format({"Records":"{:,.0f}","Mean Category Premium":"{:,.2f}","Observed churn rate":"{:.3f}%"}),use_container_width=True,hide_index=True)
    st.caption("Pearson χ² ≈ 0.01138, df=1, p≈0.915 (conventional record-level test). This neither proves risk equivalence nor establishes customer-level independence.")
    st.warning("Premium is NOT customer lifetime value, intervention responsiveness, or expected profit. The study contains no campaign outcomes; no retention effectiveness or ROI can be estimated.")
    with st.expander("View core Figure 5"):
        from_path_image("Figure_5_Clustering_Diagnostics.png")

else:
    section_title("Methods, provenance & downloads", "A defensible demo keeps clear boundaries between supplied manuscript results, new experiments, and what remains unknown.")
    st.markdown("**Demo operating mode:** Read-only aggregate research evidence. No access to raw customer-level records, no fitting, no predictions.")
    m=D["manifest"]
    left,right=st.columns(2)
    with left:
        st.markdown("**Core paper (supplied)**")
        st.write("200,000 records; three classifiers; suspicious BMI proxy; 10 BMI-excluded group-aware splits; exploratory k=2 monetary grouping.")
        st.markdown("**Extension A**")
        st.write("Four protocol cells = BMI inclusion × split strategy, five seeds, three model families, fixed group definition.")
        st.markdown("**Extension B**")
        st.write("Entropy / empirical information gain, in-sample group majority, 400 label-permutation reference replicates.")
        st.markdown("**Extension C**")
        st.write("Seed-10 record/equal-group AUC, 300 row- and 300 group-bootstrap resamples.")
    with right:
        st.markdown("**Important limitations**")
        st.write("Unknown unit of observation; feature acquisition times undocumented; repeated feature vectors do not imply duplicate people; no external validation; no verified causal retention effects.")
        st.markdown("**Dataset fingerprint**")
        st.code(m["dataset_sha256"],language=None)
        st.markdown("**Software used for original experiment artifacts**")
        st.json(m.get("versions",{}),expanded=False)
    st.markdown("### Download checked research outputs")
    chosen=st.selectbox("Data table",sorted(p.name for p in DATA.glob("*.csv")))
    st.download_button("Download selected CSV",data=(DATA/chosen).read_bytes(),file_name=chosen,mime="text/csv")
    option=st.selectbox("Figure (PNG)",sorted(p.name for p in FIGURES.glob("*.png")))
    st.download_button("Download selected figure",data=(FIGURES/option).read_bytes(),file_name=option,mime="image/png")
    st.markdown(f"Dataset reference: [{CORE['dataset_title']}]({CORE['dataset_url']})")
    st.caption("Values are loaded from precomputed artifacts created by the independently reproducible thesis notebook. The demo itself does not verify claims from user-supplied new datasets.")

st.divider()
st.caption("THESIS · Leakage-aware churn analytics | Evidence-first demonstration | Dataset-specific, research use only")
