"""Lightweight artifact validation for the precomputed Streamlit demo.
Uses standard library only. Run: python preflight.py
"""
from __future__ import annotations
import csv
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
TABLES=ROOT/'assets'/'tables'
META=ROOT/'assets'/'metadata'
FIGURES=ROOT/'assets'/'figures'


def rows(name):
    with (TABLES/name).open(newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))

core=json.loads((META/'core_summary.json').read_text(encoding='utf-8'))
m=json.loads((META/'experiment_manifest.json').read_text(encoding='utf-8'))
a=rows('A_ablation_all_seeds.csv')
summary=rows('A_ablation_summary.csv')
g=rows('B_group_label_profiles.csv')
b=rows('B_information_and_oracle.csv')[0]
perm=rows('B_permutation_reference.csv')
c=rows('C_group_weighting_and_bootstrap.csv')
check={
    '200,000 records': core['record_count']==200000,
    'churn prevalence count':core['churn_yes']+core['churn_no']==core['record_count'],
    'medical plus other category counts':sum(v['records'] for v in core['premium_categories'])==core['record_count'],
    'category Yes totals':sum(v['churn_yes'] for v in core['premium_categories'])==core['churn_yes'],
    'unique predictor groups':core['unique_predictor_vectors_without_bmi']==1769 and len(g)==1769,
    'mixed labels across groups':sum(0<float(v['churn_yes_n'])<float(v['group_n']) for v in g)==1769,
    'A 60 model fits':len(a)==60,
    'A 12 summary cells':len(summary)==12,
    'B 400 label permutations':len(perm)==400,
    'B empirical oracle':0.63<float(b['in_sample_group_oracle_accuracy'])<0.64,
    'C three representative models':len(c)==3 and {v['model'] for v in c}=={'LR','RF','GB'},
    'source SHA-256 consistent':m['dataset_sha256']=='85700a0d3f6e05c394d6ccba4ac75018c33ebee75cd6b3bed48dd82fd28ccd5e',
    'thesis figures present':all((FIGURES/f'E{i}_{rest}.png').exists() for i,rest in [(1,'factorial_ablation_auc'),(2,'label_ambiguity_and_information'),(3,'split_robustness_and_group_uncertainty')]),
    'core figures present':all((FIGURES/f'Figure_{i}_{suffix}.png').exists() for i,suffix in [(2,'Data_Audit'),(3,'Classification_and_ROC'),(4,'AUC_Uncertainty'),(5,'Clustering_Diagnostics')]),
}
for label,ok in check.items():
    print(('PASS' if ok else 'FAIL')+'  '+label)
if not all(check.values()):
    raise SystemExit(1)
print(f'\nAll {len(check)} demo artifact checks passed.')
